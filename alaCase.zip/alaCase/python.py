s=input()
print(min)